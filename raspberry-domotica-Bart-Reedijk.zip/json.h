/* 
 * File:   json.h
 * Author: bart
 *
 * Created on 8 april 2015, 12:03
 */

#ifndef JSON_H
#define	JSON_H

#ifdef	__cplusplus
extern "C" {
#endif

json_t* loadJson( void );


#ifdef	__cplusplus
}
#endif

#endif	/* JSON_H */

